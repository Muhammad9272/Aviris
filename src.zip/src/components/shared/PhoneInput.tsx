'use client';

import { useEffect, useRef } from 'react';

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  id?: string;
  className?: string;
  placeholder?: string;
  showVerifiedBadge?: boolean;
}

export default function PhoneInput({ 
  value, 
  onChange, 
  id = 'phone', 
  className = 'form-control',
  placeholder = '',
  showVerifiedBadge = false
}: PhoneInputProps) {
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const itiInstanceRef = useRef<any>(null);
  const scriptLoadedRef = useRef(false);
  const cssLoadedRef = useRef(false);

  useEffect(() => {
    // Load CSS
    if (!cssLoadedRef.current && typeof document !== 'undefined') {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/css/intlTelInput.css';
      document.head.appendChild(link);
      cssLoadedRef.current = true;
    }

    // Load JS
    const loadScript = () => {
      return new Promise<void>((resolve) => {
        if ((window as any).intlTelInput) {
          resolve();
          return;
        }

        if (scriptLoadedRef.current) {
          const checkInterval = setInterval(() => {
            if ((window as any).intlTelInput) {
              clearInterval(checkInterval);
              resolve();
            }
          }, 50);
          setTimeout(() => clearInterval(checkInterval), 5000);
          return;
        }

        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/js/intlTelInput.min.js';
        script.async = true;
        script.onload = () => {
          scriptLoadedRef.current = true;
          resolve();
        };
        document.body.appendChild(script);
      });
    };

    const initializeIntlTelInput = () => {
      if (phoneInputRef.current && (window as any).intlTelInput && !itiInstanceRef.current) {
        itiInstanceRef.current = (window as any).intlTelInput(phoneInputRef.current, {
          initialCountry: "de",
          preferredCountries: ["de", "gb", "us", "fr"],
          utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/js/utils.js"
        });

        phoneInputRef.current.addEventListener('countrychange', () => {
          if (itiInstanceRef.current) {
            onChange(itiInstanceRef.current.getNumber());
          }
        });
      }
    };

    loadScript().then(initializeIntlTelInput);

    return () => {
      if (itiInstanceRef.current) {
        itiInstanceRef.current.destroy?.();
        itiInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <>
      <style jsx global>{`
        .phone-wrapper {
          position: relative;
          width: 100%;
        }
        .iti {
          width: 100% !important;
          display: block;
        }
           .iti__selected-country-primary {
          background: #f3f3f3;
          border-radius: 10px 0px 0px 10px;
          padding: 12px;
        }
        .iti__input {
          width: 100% !important;
          border: 2px solid #E5E7EB !important;
          border-radius: 12px !important;
          padding: 14px 16px 14px 52px !important;
          font-size: 15px !important;
          color: #374151 !important;
          background-color: #FFFFFF !important;
          transition: all 0.3s ease !important;
          height: auto !important;
          line-height: 1.5 !important;
        }
        .iti__input:focus {
          border-color: var(--aviris-secondary, #16a34a) !important;
          box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.1) !important;
          outline: none !important;
        }
        .iti__input::placeholder {
          color: #9CA3AF !important;
        }
        .iti__country-container {
          position: absolute !important;
          left: 0 !important;
          top: 0 !important;
          bottom: 0 !important;
        }
        .iti__selected-flag {
          padding: 0 8px 0 12px !important;
          border-radius: 12px 0 0 12px !important;
          background: transparent !important;
          display: flex !important;
          align-items: center !important;
          height: 100% !important;
        }
        .iti__selected-flag:hover,
        .iti__selected-flag:focus {
          background: transparent !important;
        }
        .iti__arrow {
          margin-left: 6px !important;
          border-left: 4px solid transparent !important;
          border-right: 4px solid transparent !important;
          border-top: 5px solid #374151 !important;
        }
        .iti__country-list {
          border-radius: 12px !important;
          box-shadow: 0 4px 24px rgba(0, 0, 0, 0.1) !important;
          border: 2px solid #E5E7EB !important;
          margin-top: 4px !important;
          max-height: 200px !important;
        }
        .iti__country {
          padding: 10px 12px !important;
          transition: all 0.2s ease !important;
        }
        .iti__country:hover,
        .iti__country.iti__highlight {
          background-color: rgba(22, 163, 74, 0.1) !important;
        }
        .iti__flag-box {
          margin-right: 8px !important;
        }
        .iti__dial-code {
          color: #6B7280 !important;
        }
        .verified-badge {
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          border-radius: 10px;
          padding: 4px 10px;
          background: #8bbcae45;
          color: #1a5e4a;
          font-size: 0.75rem;
          white-space: nowrap;
          z-index: 10;
        }

      `}</style>

      <div className="phone-wrapper">
        <input
          type="tel"
          id={id}
          ref={phoneInputRef}
          className="iti__input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
        />
        {showVerifiedBadge && (
          <span className="verified-badge">
            <i className="ri-checkbox-circle-fill me-1"></i>
            Verified
          </span>
        )}
      </div>
    </>
  );
}
