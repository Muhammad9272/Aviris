'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import '@/styles/front/components/navbar.css'

export default function FrontendNav() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <>
      {/* Navigation */}
      <nav className={`navbar navbar-expand-lg navbar-custom ${scrolled ? 'scrolled' : ''}`}>
        <div className="container">
          {/* Logo */}
          <Link className="navbar-brand" href="/front">
            <img src="/front/img/logo.png" alt="AVIRIS" className="logo-img" />
          </Link>

          {/* Mobile Toggle */}
          <button 
            className="navbar-toggler" 
            type="button"
            onClick={() => setMobileMenuOpen(true)}
          >
            <i className="fas fa-bars"></i>
          </button>

          {/* Desktop Navigation Menu */}
          <div className="collapse navbar-collapse d-none d-xl-flex" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/pricing' ? 'active' : ''}`} href="/front/pricing">Pricing</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/features' ? 'active' : ''}`} href="/front/features">Features</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/downloads' ? 'active' : ''}`} href="/front/downloads">Download</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/blogs' ? 'active' : ''}`} href="/front/blogs">Blogs</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/business' ? 'active' : ''}`} href="/front/business">For Business</Link>
              </li>
              <li className="nav-item">
                <Link className={`nav-link ${pathname === '/front/contact' ? 'active' : ''}`} href="/front/contact">Contact us</Link>
              </li>
            </ul>

            {/* Right Side Items */}
            <div className="d-flex align-items-center gap-3">
              {/* Language Dropdown */}
              <div className="dropdown flag-dropdown">
                <button className="btn dropdown-toggle" type="button" id="langDrop" data-bs-toggle="dropdown">
                  <span className="fi fi-us"></span>
                </button>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item active" href="#" onClick={(e) => e.preventDefault()}><span className="fi fi-us"></span> English</a></li>
                  <li><a className="dropdown-item" href="#" onClick={(e) => e.preventDefault()}><span className="fi fi-de"></span> German</a></li>
                </ul>
              </div>

              {/* Get Started Button */}
              <Link href="/front/pricing" className="btn-primary-custom">
                Get Started
                <i className="fas fa-arrow-right"></i>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Offcanvas Sidebar */}
      <div className={`offcanvas offcanvas-start offcanvas-mobile-nav ${mobileMenuOpen ? 'show' : ''}`} tabIndex={-1} style={{visibility: mobileMenuOpen ? 'visible' : 'hidden'}}>
        <div className="offcanvas-header">
          <h5 className="offcanvas-title d-flex align-items-center gap-2">
            <img src="/front/img/logo.png" alt="AVIRIS" style={{height: '32px'}} />
          </h5>
          <button type="button" className="btn-close" onClick={() => setMobileMenuOpen(false)}></button>
        </div>
        <div className="offcanvas-body">
          {/* Mobile Navigation Menu */}
          <div className="mobile-nav-menu">
            <Link href="/front/pricing" className={`mobile-nav-link ${pathname === '/front/pricing' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>Pricing</Link>
            <Link href="/front/features" className={`mobile-nav-link ${pathname === '/front/features' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>Features</Link>
            <Link href="/front/downloads" className={`mobile-nav-link ${pathname === '/front/downloads' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>Download</Link>
            <Link href="/front/blogs" className={`mobile-nav-link ${pathname === '/front/blogs' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>Blogs</Link>
            <Link href="/front/business" className={`mobile-nav-link ${pathname === '/front/business' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>For Business</Link>
            <Link href="/front/contact" className={`mobile-nav-link ${pathname === '/front/contact' ? 'active' : ''}`} onClick={() => setMobileMenuOpen(false)}>Contact us</Link>
          </div>

          {/* Mobile CTA Button */}
          <div className="mobile-cta-section">
            <Link href="/front/pricing" className="btn-primary-custom w-100 justify-content-center" onClick={() => setMobileMenuOpen(false)}>
              Get Started
              <i className="fas fa-arrow-right"></i>
            </Link>
          </div>
        </div>
      </div>

      {/* Backdrop */}
      {mobileMenuOpen && <div className="offcanvas-backdrop fade show" onClick={() => setMobileMenuOpen(false)}></div>}
    </>
  )
}