/**
 * Centralized Route Configuration
 * Define all application routes here for easy management and updates
 */

export const routes = {
  // Front-facing pages (no prefix)
  home: '/',
  features: '/features',
  pricing: '/pricing',
  downloads: '/downloads',
  business: '/business',
  contact: '/contact',
  blogs: '/blogs',
  blogDetails: (id: string) => `/blogs/${id}`,
  terms: '/terms',
  privacy: '/privacy',
  imprint: '/imprint',

  // Authentication pages (no prefix)
  auth: {
    login: '/login',
    register: '/register',
    forgotPassword: '/forgot-password',
    resetPassword: '/reset-password',
  },

  // User Dashboard pages (prefix: /user)
  user: {
    dashboard: '/user',
    profile: '/user/profile',
    settings: '/user/settings',
    billing: '/user/billing',
    pricing: '/user/pricing',
    downloads: '/user/downloads',
    support: '/user/support',
  },
} as const;

// Type helper for route parameters
export type Routes = typeof routes;
